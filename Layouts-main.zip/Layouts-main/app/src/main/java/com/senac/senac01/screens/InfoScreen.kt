package com.senac.senac01.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.senac.senac01.R

@Composable
fun InfoScreen() {
    Image(
        painter = painterResource(id =
                R.drawable.avatar),
        contentDescription = "Avatar",
        modifier = Modifier.size(200.dp),
        contentScale = ContentScale.Crop)
    Text(
        text = "Fabiano Oss",
        fontSize = 26.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center
    )
    Row() {
        Image(imageVector = Icons.Default.Email, contentDescription = "")
        Spacer(modifier = Modifier.size(4.dp))
        Text(
            text = "fabiano.oss@prof.senac.sc.br"
        )
    }
}